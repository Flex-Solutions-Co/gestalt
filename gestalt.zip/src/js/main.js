import "../blocks/casestudyslider/view";
import "../blocks/testimonials-slider/view";
import "../blocks/courseslider/view";
import "../blocks/mediaandcontentslider/view";
import "../blocks/blogreadmoreslider/view";
import "../blocks/testimonials-slider/view";
